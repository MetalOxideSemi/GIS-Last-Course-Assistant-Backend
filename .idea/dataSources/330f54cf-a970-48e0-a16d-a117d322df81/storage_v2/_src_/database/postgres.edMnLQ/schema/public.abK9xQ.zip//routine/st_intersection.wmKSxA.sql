create function st_intersection(text, text) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.ST_Intersection($1::public.geometry, $2::public.geometry);
$$;

alter function st_intersection(text, text) owner to gislab;

