create function ganos_update() returns text
    strict
    language plpgsql
as
$$
DECLARE
rec RECORD;
sql text;
BEGIN
FOR rec IN
SELECT extname
FROM pg_extension
WHERE extname like 'ganos_%'
LOOP
sql = 'ALTER EXTENSION '
|| rec.extname
|| ' UPDATE ';
RAISE NOTICE '%', sql;
EXECUTE sql;
END LOOP;
return 'All Ganos extensions have updated to latest version';
END
$$;

alter function ganos_update() owner to gislab;

