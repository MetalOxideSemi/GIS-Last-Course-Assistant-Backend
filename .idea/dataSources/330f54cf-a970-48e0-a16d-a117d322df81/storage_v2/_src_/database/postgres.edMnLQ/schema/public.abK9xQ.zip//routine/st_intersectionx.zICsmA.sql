create function st_intersectionx(text, text) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.ST_Intersectionx($1::public.geometry, $2::public.geometry);
$$;

alter function st_intersectionx(text, text) owner to gislab;

