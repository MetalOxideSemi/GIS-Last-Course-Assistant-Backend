create function st_dwithinx(geom1 geometry, geom2 geometry, double precision) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT $1 OPERATOR(public.&&) public._ST_Expandx($2,$3) AND $2 OPERATOR(public.&&) public._ST_Expandx($1,$3) AND public._ST_DWithin($1, $2, $3)
$$;

alter function st_dwithinx(geometry, geometry, double precision) owner to gislab;

