create function ganos_rollback_prepared() returns text
    strict
    language plpgsql
as
$$
DECLARE
rec RECORD;
sql text;
BEGIN
FOR rec IN
select gid
from
pg_prepared_xacts
where
gid like 'ganos_%'
AND
(regexp_split_to_array(gid, E'_'))[2]::integer not in (select pid from pg_stat_activity)
and
database = current_database()
LOOP
sql = 'ROLLBACK PREPARED '
|| quote_literal(rec.gid) || ' ;';
RAISE NOTICE '%', sql;
END LOOP;
return 'Use previous sql to rollback orphan prepared transactions.';
END
$$;

alter function ganos_rollback_prepared() owner to gislab;

