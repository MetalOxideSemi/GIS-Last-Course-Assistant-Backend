create function st_version() returns text
    immutable
    language sql
as
$$
Select '3.8.0 for PostgreSQL 12 (Build 20210425)'::text AS version
$$;

alter function st_version() owner to gislab;

