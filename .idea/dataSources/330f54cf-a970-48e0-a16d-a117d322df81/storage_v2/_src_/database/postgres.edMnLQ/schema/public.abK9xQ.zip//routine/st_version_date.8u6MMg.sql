create function st_version_date() returns text
    immutable
    language sql
as
$$
Select '20210425'::text AS version
$$;

alter function st_version_date() owner to gislab;

