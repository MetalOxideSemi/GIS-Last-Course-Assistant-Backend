create function ganos_spatialref_version() returns text
    immutable
    language sql
as
$$
Select '3.8'::text AS version
$$;

alter function ganos_spatialref_version() owner to gislab;

