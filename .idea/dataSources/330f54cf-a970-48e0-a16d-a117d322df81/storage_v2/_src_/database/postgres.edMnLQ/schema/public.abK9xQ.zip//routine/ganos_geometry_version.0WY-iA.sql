create function ganos_geometry_version() returns text
    immutable
    language sql
as
$$
Select '3.8'::text AS version
$$;

alter function ganos_geometry_version() owner to gislab;

