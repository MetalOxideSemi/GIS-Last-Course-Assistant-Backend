create function st_equals(geom1 geometry, geom2 geometry) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT $1 OPERATOR(public.~=) $2 AND public._ST_Equals($1,$2)
$$;

comment on function st_equals(geometry, geometry) is 'args: A, B - Returns true if the given geometries represent the same geometry. Directionality is ignored.';

alter function st_equals(geometry, geometry) owner to gislab;

